from automate import *


def menu(power, chemin, choixAutomate, adjectif, veriMinimiser, onStandard):
    print(jaune + "\n[*]Voici la table de transition de l'automate n°" + choixAutomate + " " + adjectif + " :\n" + normal)

    automate = Automate()
    automate.lireAutomateSurFichier(chemin)
    automate.afficherAutomate()

    veriStandard = automate.estStandard(True)
    veriDerterministe = automate.estDeterministe(True)
    veriComplet = automate.estComplet(True)

    if power == False:
        return

    print(bleu + "\n[-]Que voulez-vous faire ?" + normal)

    num = 0
    choixVeri = []

    if onStandard:
        veriStandard = True

    if veriStandard == False:
        num += 1
        choixVeri.append(str(num))
        print("   [" + str(num) + "]Standardiser l'automate.")
    if veriDerterministe == False:
        num += 1
        choixVeri.append(str(num))
        print("   [" + str(num) + "]Déterminiser l'automate.")
    elif veriDerterministe == True and veriComplet == False:
        num += 1
        choixVeri.append(str(num))
        print("   [" + str(num) + "]Commpléter l'automate.")
    elif veriDerterministe == True and veriComplet == True:
        if not veriMinimiser:
            num += 1
            choixVeri.append(str(num))
            print("   [" + str(num) + "]Minimiser l'automate.")

        num += 1
        choixVeri.append(str(num))
        print("   [" + str(num) + "]Lire des mots.")

    choixVeri.append('q')

    choix = input(" ---> :")
    while choix not in choixVeri:
        print(rouge + "\n[!]Choix incorrecte, veuillez réessayer." + normal)
        choix = input(" ---> :")

    if choix == 'q':
        print(rouge + "\n[*]Retour arrière." + normal)

    else:

        if choix == '1' and veriStandard == False:

            automate.standardiserAutomate()
            menu(False, "exe.txt", choixAutomate, "standard", False, True)

        elif (choix == '1' and veriDerterministe == False) or (choix == '2' and veriDerterministe == False):

            automate.determiniserAutoamte()
            menu(True, "exe.txt", choixAutomate, "déterministe", False, True)

        elif veriDerterministe == True and veriComplet == False:
            if choix == '1' or choix == '2':

                automate.completerAutomate()
                menu(True, "exe.txt", choixAutomate, "déterministe et complet", False, True)

        elif veriDerterministe == True and veriComplet == True:

            if (choix == '2' and veriStandard == False and veriMinimiser == False) or (choix == '1' and veriStandard == True and veriMinimiser == False):
                print(rouge + "\n  ----[MINIMISATION]----\n" + normal)
                pause(2)

                automate.afficherAutomate()
                mot = "déterministe, complet et minimisé"
                deja = automate.minimiserAutomate()

                if deja:
                    mot += " (même si cet automate était déjà minimisé au maximum)"

                pause(2)

                menu(True, "exe.txt", choixAutomate, mot, True, True)

            if (choix == '2' and veriStandard == False and veriMinimiser == True) or (choix == '1' and veriStandard == True and veriMinimiser == True) or (choix == '3' and veriStandard == False and veriMinimiser == False) or (choix == '2' and veriStandard == True and veriMinimiser == False):
                print(bleu + "\n[?]Voulez-vous lire le langage normal ou le langage complémentaire ?" + normal + "\n   [1]Normal.\n   [2]Complémentaire.")

                chemin = "exe.txt"

                choix2 = input(" ---> :")
                while choix2 not in ['1', '2', 'q']:
                    print(rouge + "\n[!]Choix incorrecte, veuillez réessayer." + normal)
                    choix2 = input(" ---> :")

                if choix2 == 'q':
                    print(rouge + "\n[*]Retour arrière." + normal)

                elif choix2 == '1':
                    print(jaune + "\n[*]Lecture du langage de l'automate n°" + choixAutomate + " " + adjectif + " :\n" + normal)
                    automate.afficherAutomate()
                    automate.lireMotsAutomate(choixAutomate)

                elif choix2 == '2':
                    automate.complementariserAutomate()
                    automate2 = Automate()
                    automate2.lireAutomateSurFichier(chemin)
                    print(jaune + "\n[*]Lecture du langage complémentaire de l'automate n°" + choixAutomate + " " + adjectif + " :\n" + normal)
                    automate2.afficherAutomate()
                    automate2.lireMotsAutomate(choixAutomate)
