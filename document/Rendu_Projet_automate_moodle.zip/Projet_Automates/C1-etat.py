class Etat:

    def __init__(self, nom):
        self.nom = nom
        self.etatInitial = ''
        self.etatTerminal = ''
        self.transition = {}
        self.objetTransition = {}

    def initialisationTransition(self, nbAlphabet, alphabet):
        for i in range(nbAlphabet):
            self.transition[alphabet[i]] = ""
            self.objetTransition[alphabet[i]] = 'XXX'
